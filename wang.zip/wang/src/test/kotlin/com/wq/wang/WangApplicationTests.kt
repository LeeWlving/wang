package com.wq.wang

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class WangApplicationTests {

	@Test
	fun contextLoads() {
	}

}
